export interface Barber {
  id: string
  name: string
  instagram: string
  photo_url: string | null
  created_at: string
}

export interface Appointment {
  id: string
  barber_id: string
  client_name: string
  client_phone: string
  date: string
  time: string
  created_at: string
}

export interface TimeSlot {
  time: string
  available: boolean
  appointmentId?: string
}
