// Direct Supabase REST API calls - more reliable than ORM in this environment
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

async function supabaseFetch(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${SUPABASE_URL}/rest/v1${endpoint}`, {
    ...options,
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
      ...options.headers,
    },
  })

  if (!response.ok) {
    const error = await response.text()
    throw new Error(`Supabase error: ${error}`)
  }

  return response.json()
}

export async function getBarbers() {
  console.log("[v0] Fetching barbers from Supabase REST API...")
  const barbers = await supabaseFetch("/barbers?select=*&order=name.asc")
  console.log("[v0] Fetched barbers:", barbers?.length || 0)
  return barbers
}

export async function getBarberById(id: string) {
  const barbers = await supabaseFetch(`/barbers?id=eq.${id}&select=*`)
  return barbers[0]
}

export async function getAppointmentsByBarberAndDate(barberId: string, date: string) {
  const appointments = await supabaseFetch(
    `/appointments?barber_id=eq.${barberId}&date=eq.${date}&select=*&order=time.asc`,
  )
  return appointments
}

export async function createAppointmentInDB(
  barberId: string,
  clientName: string,
  clientPhone: string,
  date: string,
  time: string,
) {
  const appointment = await supabaseFetch("/appointments", {
    method: "POST",
    body: JSON.stringify({
      barber_id: barberId,
      client_name: clientName,
      client_phone: clientPhone,
      date,
      time,
    }),
  })
  return appointment[0]
}

export async function deleteAppointmentFromDB(appointmentId: string) {
  await supabaseFetch(`/appointments?id=eq.${appointmentId}`, {
    method: "DELETE",
  })
}

export async function getAllAppointments() {
  const appointments = await supabaseFetch(`/appointments?select=*,barbers(name,instagram)&order=date.asc,time.asc`)
  return appointments
}
