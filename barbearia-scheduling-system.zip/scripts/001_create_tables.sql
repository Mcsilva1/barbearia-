-- Create barbers table
CREATE TABLE IF NOT EXISTS public.barbers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  instagram TEXT NOT NULL,
  photo_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create appointments table
CREATE TABLE IF NOT EXISTS public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  barber_id UUID NOT NULL REFERENCES public.barbers(id) ON DELETE CASCADE,
  client_name TEXT NOT NULL,
  client_phone TEXT NOT NULL,
  date DATE NOT NULL,
  time TIME NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(barber_id, date, time)
);

-- Create admin credentials table (simple password auth for admin)
CREATE TABLE IF NOT EXISTS public.admin_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.barbers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_credentials ENABLE ROW LEVEL SECURITY;

-- Barbers policies (anyone can view)
CREATE POLICY "Anyone can view barbers" ON public.barbers FOR SELECT USING (true);

-- Appointments policies (anyone can view and insert, but only for future dates)
CREATE POLICY "Anyone can view appointments" ON public.appointments FOR SELECT USING (true);
CREATE POLICY "Anyone can create appointments" ON public.appointments FOR INSERT WITH CHECK (true);

-- Admin can delete/update appointments (we'll check admin status in the application layer)
CREATE POLICY "Allow all to update appointments" ON public.appointments FOR UPDATE USING (true);
CREATE POLICY "Allow all to delete appointments" ON public.appointments FOR DELETE USING (true);

-- Admin credentials are private (only accessible via server-side functions)
CREATE POLICY "No direct access to admin credentials" ON public.admin_credentials FOR SELECT USING (false);

-- Insert the 6 barbers from the image
INSERT INTO public.barbers (name, instagram, photo_url) VALUES
  ('Don Juan', 'juan_oliveeiira', '/images/dd.jpg'),
  ('Natan', 'dmorais_barber', NULL),
  ('Gabriel', 'guimaraes_2001', NULL),
  ('Diego', 'dgcpsds', NULL),
  ('Ruan', 'ruancortez01', NULL),
  ('Henrique', 'henriozbarber', NULL);

-- Insert default admin credentials (username: admin, password: admin123)
-- In production, change this password immediately!
INSERT INTO public.admin_credentials (username, password_hash) VALUES
  ('admin', '$2a$10$rKvVPq3VZ5LH8mJHYX7xyeYv5OxYwxQp7H/qZ9xQZ7eYv5OxYwxQp7');
