"use client"

import type React from "react"

import { useState, useEffect } from "react"
import type { Barber, TimeSlot } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Calendar, Instagram, ArrowLeft, Lock } from "lucide-react"
import Link from "next/link"
import { createAppointment, deleteAppointment, verifyAdminPassword, getAppointments } from "@/app/actions"

interface BookingClientProps {
  barber: Barber
  initialDate: string
}

function generateTimeSlots(): string[] {
  const slots: string[] = []
  for (let hour = 8; hour <= 18; hour++) {
    slots.push(`${hour.toString().padStart(2, "0")}:00`)
  }
  return slots
}

export default function BookingClient({ barber, initialDate }: BookingClientProps) {
  const [selectedDate, setSelectedDate] = useState(initialDate)
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([])
  const [selectedTime, setSelectedTime] = useState<string | null>(null)
  const [showBookingForm, setShowBookingForm] = useState(false)
  const [clientName, setClientName] = useState("")
  const [clientPhone, setClientPhone] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showAdminDialog, setShowAdminDialog] = useState(false)
  const [adminPassword, setAdminPassword] = useState("")
  const [selectedAppointmentId, setSelectedAppointmentId] = useState<string | null>(null)

  useEffect(() => {
    loadTimeSlots()
  }, [selectedDate])

  async function loadTimeSlots() {
    const allSlots = generateTimeSlots()

    const appointments = await getAppointments(barber.id, selectedDate)

    const bookedTimes = new Set(appointments?.map((apt: any) => apt.time) || [])

    const slots: TimeSlot[] = allSlots.map((time) => {
      const appointment = appointments?.find((apt: any) => apt.time === time)
      return {
        time,
        available: !bookedTimes.has(time),
        appointmentId: appointment?.id,
      }
    })

    setTimeSlots(slots)
  }

  function handleTimeClick(slot: TimeSlot) {
    if (slot.available) {
      setSelectedTime(slot.time)
      setShowBookingForm(true)
    } else {
      // Try to cancel - show admin dialog
      setSelectedAppointmentId(slot.appointmentId || null)
      setShowAdminDialog(true)
    }
  }

  async function handleSubmitBooking(e: React.FormEvent) {
    e.preventDefault()
    if (!selectedTime) return

    setIsSubmitting(true)

    const formData = new FormData()
    formData.append("barberId", barber.id)
    formData.append("clientName", clientName)
    formData.append("clientPhone", clientPhone)
    formData.append("date", selectedDate)
    formData.append("time", selectedTime)

    const result = await createAppointment(formData)

    if (result.success) {
      setShowBookingForm(false)
      setClientName("")
      setClientPhone("")
      setSelectedTime(null)
      await loadTimeSlots()
      alert("Agendamento realizado com sucesso!")
    } else {
      alert("Erro ao agendar: " + result.error)
    }

    setIsSubmitting(false)
  }

  async function handleCancelAppointment() {
    const isValid = await verifyAdminPassword(adminPassword)

    if (!isValid) {
      alert("Senha de administrador incorreta!")
      return
    }

    if (!selectedAppointmentId) return

    const result = await deleteAppointment(selectedAppointmentId, barber.id)

    if (result.success) {
      setShowAdminDialog(false)
      setAdminPassword("")
      setSelectedAppointmentId(null)
      await loadTimeSlots()
      alert("Agendamento cancelado com sucesso!")
    } else {
      alert("Erro ao cancelar: " + result.error)
    }
  }

  return (
    <div className="min-h-screen bg-background pb-12">
      {/* Header */}
      <div className="bg-card border-b-2 border-primary/20">
        <div className="max-w-3xl mx-auto px-4 py-6">
          <Link href="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-4">
            <ArrowLeft className="w-5 h-5" />
            <span className="font-semibold">Voltar</span>
          </Link>

          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-2xl">
              {barber.name.charAt(0)}
            </div>
            <div>
              <h1 className="text-3xl font-black text-primary">{barber.name.toUpperCase()}</h1>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Instagram className="w-4 h-4" />
                <span>@{barber.instagram}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Date Selector */}
      <div className="max-w-3xl mx-auto px-4 mt-8">
        <div className="bg-card rounded-lg p-6 border-2 border-primary/20 shadow-lg">
          <Label htmlFor="date" className="text-lg font-bold text-foreground mb-2 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-primary" />
            Selecione a data
          </Label>
          <Input
            id="date"
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            min={initialDate}
            className="text-lg font-semibold"
          />
        </div>
      </div>

      {/* Time Slots */}
      <div className="max-w-3xl mx-auto px-4 mt-6">
        <h2 className="text-2xl font-bold text-foreground mb-4">Horários Disponíveis</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {timeSlots.map((slot) => (
            <button
              key={slot.time}
              onClick={() => handleTimeClick(slot)}
              disabled={isSubmitting}
              className={`p-4 rounded-lg font-bold text-lg transition-all border-2 ${
                slot.available
                  ? "bg-card border-primary/40 text-primary hover:bg-primary hover:text-primary-foreground"
                  : "bg-muted border-muted text-muted-foreground cursor-pointer hover:border-destructive"
              }`}
            >
              {slot.time}
              {!slot.available && (
                <div className="flex items-center justify-center gap-1 mt-1 text-xs">
                  <Lock className="w-3 h-3" />
                  <span>Ocupado</span>
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Booking Form Dialog */}
      <Dialog open={showBookingForm} onOpenChange={setShowBookingForm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-primary">Confirmar Agendamento</DialogTitle>
            <DialogDescription>
              {barber.name} - {selectedDate} às {selectedTime}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmitBooking} className="space-y-4">
            <div>
              <Label htmlFor="clientName">Seu nome</Label>
              <Input
                id="clientName"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                required
                placeholder="João Silva"
              />
            </div>

            <div>
              <Label htmlFor="clientPhone">Seu telefone</Label>
              <Input
                id="clientPhone"
                type="tel"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                required
                placeholder="(11) 99999-9999"
              />
            </div>

            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={() => setShowBookingForm(false)} className="flex-1">
                Cancelar
              </Button>
              <Button type="submit" disabled={isSubmitting} className="flex-1">
                {isSubmitting ? "Agendando..." : "Confirmar"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Admin Password Dialog */}
      <Dialog open={showAdminDialog} onOpenChange={setShowAdminDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-destructive">Cancelar Agendamento</DialogTitle>
            <DialogDescription>Digite a senha de administrador para cancelar este horário</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="adminPassword">Senha de Admin</Label>
              <Input
                id="adminPassword"
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Digite a senha"
              />
            </div>

            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowAdminDialog(false)
                  setAdminPassword("")
                }}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button type="button" variant="destructive" onClick={handleCancelAppointment} className="flex-1">
                Confirmar Cancelamento
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
