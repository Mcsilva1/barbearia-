import { getBarberById } from "@/lib/supabase/api"
import { notFound } from "next/navigation"
import BookingClient from "./booking-client"

export default async function BarberPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  const barber = await getBarberById(id)

  if (!barber) {
    notFound()
  }

  // Get today's date in YYYY-MM-DD format
  const today = new Date().toISOString().split("T")[0]

  return <BookingClient barber={barber} initialDate={today} />
}
