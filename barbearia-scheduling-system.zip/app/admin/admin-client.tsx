"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Clock, Phone, User, Trash2, Lock } from "lucide-react"
import { deleteAppointment, verifyAdminPassword } from "@/app/actions"
import { useRouter } from "next/navigation"

interface Appointment {
  id: string
  client_name: string
  client_phone: string
  date: string
  time: string
  barbers: {
    name: string
    instagram: string
  }
}

interface AdminClientProps {
  initialAppointments: Appointment[]
}

export function AdminClient({ initialAppointments }: AdminClientProps) {
  const [appointments, setAppointments] = useState(initialAppointments)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    const isValid = await verifyAdminPassword(password)
    if (isValid) {
      setIsAuthenticated(true)
      setError("")
    } else {
      setError("Senha incorreta")
    }
  }

  const handleDeleteClick = (appointment: Appointment) => {
    setSelectedAppointment(appointment)
    setDeleteDialogOpen(true)
  }

  const handleDeleteConfirm = async () => {
    if (!selectedAppointment) return

    setIsDeleting(true)
    const result = await deleteAppointment(selectedAppointment.id, selectedAppointment.barbers.name)

    if (result.success) {
      setAppointments((prev) => prev.filter((apt) => apt.id !== selectedAppointment.id))
      setDeleteDialogOpen(false)
      setSelectedAppointment(null)
      router.refresh()
    } else {
      setError("Erro ao cancelar agendamento")
    }
    setIsDeleting(false)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString + "T00:00:00")
    return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" })
  }

  const formatTime = (timeString: string) => {
    return timeString.slice(0, 5)
  }

  const groupByDate = (appointments: Appointment[]) => {
    const grouped: Record<string, Appointment[]> = {}
    appointments.forEach((apt) => {
      if (!grouped[apt.date]) {
        grouped[apt.date] = []
      }
      grouped[apt.date].push(apt)
    })
    return grouped
  }

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto mt-20">
        <Card className="bg-zinc-900 border-amber-400/20">
          <CardHeader>
            <CardTitle className="text-amber-400 flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Acesso Administrativo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="password" className="text-gray-300">
                  Senha de Admin
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-zinc-800 border-amber-400/30 text-white"
                  placeholder="Digite a senha"
                />
              </div>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <Button type="submit" className="w-full bg-amber-400 hover:bg-amber-500 text-black font-bold">
                Entrar
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  const groupedAppointments = groupByDate(appointments)
  const sortedDates = Object.keys(groupedAppointments).sort()

  return (
    <>
      <div className="space-y-8">
        {sortedDates.length === 0 ? (
          <Card className="bg-zinc-900 border-amber-400/20">
            <CardContent className="py-12 text-center">
              <p className="text-gray-400 text-lg">Nenhum agendamento encontrado</p>
            </CardContent>
          </Card>
        ) : (
          sortedDates.map((date) => (
            <div key={date}>
              <h2 className="text-2xl font-bold text-amber-400 mb-4">{formatDate(date)}</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {groupedAppointments[date].map((appointment) => (
                  <Card
                    key={appointment.id}
                    className="bg-zinc-900 border-amber-400/20 hover:border-amber-400/40 transition-colors"
                  >
                    <CardHeader>
                      <CardTitle className="text-amber-400 text-lg flex items-center justify-between">
                        <span>{appointment.barbers.name}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteClick(appointment)}
                          className="text-red-500 hover:text-red-400 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex items-center gap-2 text-gray-300">
                        <Clock className="w-4 h-4 text-amber-400" />
                        <span className="font-semibold">{formatTime(appointment.time)}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-300">
                        <User className="w-4 h-4 text-amber-400" />
                        <span>{appointment.client_name}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-300">
                        <Phone className="w-4 h-4 text-amber-400" />
                        <span>{appointment.client_phone}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="bg-zinc-900 border-amber-400/20 text-white">
          <DialogHeader>
            <DialogTitle className="text-amber-400">Cancelar Agendamento</DialogTitle>
            <DialogDescription className="text-gray-400">
              Tem certeza que deseja cancelar este agendamento?
            </DialogDescription>
          </DialogHeader>
          {selectedAppointment && (
            <div className="space-y-2 py-4">
              <p className="text-gray-300">
                <strong className="text-amber-400">Cliente:</strong> {selectedAppointment.client_name}
              </p>
              <p className="text-gray-300">
                <strong className="text-amber-400">Barbeiro:</strong> {selectedAppointment.barbers.name}
              </p>
              <p className="text-gray-300">
                <strong className="text-amber-400">Data:</strong> {formatDate(selectedAppointment.date)}
              </p>
              <p className="text-gray-300">
                <strong className="text-amber-400">Horário:</strong> {formatTime(selectedAppointment.time)}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              className="bg-zinc-800 border-amber-400/30 text-white hover:bg-zinc-700"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleDeleteConfirm}
              disabled={isDeleting}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {isDeleting ? "Cancelando..." : "Confirmar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
