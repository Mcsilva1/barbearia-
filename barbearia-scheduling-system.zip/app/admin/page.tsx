import { getAllAppointments } from "@/lib/supabase/api"
import { AdminClient } from "./admin-client"

export default async function AdminPage() {
  const appointments = await getAllAppointments()

  return (
    <div className="min-h-screen bg-black">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-amber-400 mb-2">Painel Administrativo</h1>
          <p className="text-gray-400">Gerencie todos os agendamentos da barbearia</p>
        </div>

        <AdminClient initialAppointments={appointments} />
      </div>
    </div>
  )
}
