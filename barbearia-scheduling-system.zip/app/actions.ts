"use server"

import { createAppointmentInDB, deleteAppointmentFromDB, getAppointmentsByBarberAndDate } from "@/lib/supabase/api"
import { revalidatePath } from "next/cache"

export async function createAppointment(formData: FormData) {
  try {
    const barberId = formData.get("barberId") as string
    const clientName = formData.get("clientName") as string
    const clientPhone = formData.get("clientPhone") as string
    const date = formData.get("date") as string
    const time = formData.get("time") as string

    const data = await createAppointmentInDB(barberId, clientName, clientPhone, date, time)

    revalidatePath(`/barber/${barberId}`)
    return { success: true, data }
  } catch (error: any) {
    return { success: false, error: error.message }
  }
}

export async function deleteAppointment(appointmentId: string, barberId: string) {
  try {
    await deleteAppointmentFromDB(appointmentId)

    revalidatePath(`/barber/${barberId}`)
    return { success: true }
  } catch (error: any) {
    return { success: false, error: error.message }
  }
}

export async function getAppointments(barberId: string, date: string) {
  try {
    return await getAppointmentsByBarberAndDate(barberId, date)
  } catch (error: any) {
    console.error("[v0] Error loading appointments:", error)
    return []
  }
}

export async function verifyAdminPassword(password: string) {
  // Simple password check - in production, use bcrypt
  // For this demo, the password is "admin123"
  return password === "admin123"
}
