import { getBarbers } from "@/lib/supabase/api"
import type { Barber } from "@/lib/types"
import Link from "next/link"
import { Instagram, Settings } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default async function Home() {
  const barbers = await getBarbers()

  return (
    <div className="min-h-screen bg-background">
      {/* Logo */}
      <div className="flex justify-center pt-8 pb-6">
        <Image src="/images/dd.jpg" alt="Don Juan Barbearia" width={120} height={120} className="rounded-full" />
      </div>

      {/* Title */}
      <div className="text-center mb-8 px-4">
        <h1 className="text-5xl md:text-6xl font-black text-primary mb-2 tracking-tight">AGENDAR</h1>
        <p className="text-muted-foreground text-lg">Escolha seu barbeiro</p>
      </div>

      {/* Barbers List */}
      <div className="max-w-3xl mx-auto px-4 pb-12">
        <div className="flex flex-col gap-4">
          {barbers?.map((barber: Barber) => (
            <Link key={barber.id} href={`/barber/${barber.id}`} className="group">
              <div className="bg-card hover:bg-accent transition-colors rounded-lg p-4 border-2 border-primary/20 hover:border-primary shadow-lg">
                <div className="flex items-center gap-4">
                  {/* Barber Photo Placeholder */}
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl flex-shrink-0">
                    {barber.name.charAt(0)}
                  </div>

                  <div className="flex-1">
                    <h2 className="text-xl font-bold text-foreground mb-1">AGENDAR COM {barber.name.toUpperCase()}</h2>
                    <div className="flex items-center gap-2 text-primary">
                      <Instagram className="w-5 h-5" />
                      <span className="font-semibold">@{barber.instagram}</span>
                    </div>
                  </div>

                  <div className="text-primary group-hover:translate-x-1 transition-transform">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-8 flex justify-center">
          <Link href="/admin">
            <Button
              variant="outline"
              className="bg-zinc-900 border-primary/30 hover:bg-zinc-800 hover:border-primary text-primary font-semibold gap-2"
            >
              <Settings className="w-5 h-5" />
              Painel Administrativo
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
